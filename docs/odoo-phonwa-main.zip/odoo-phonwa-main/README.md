# Odoo em Docker (On-Premise)

Projeto para execução do Odoo com PostgreSQL usando Docker Compose.

## Requisitos
- Ubuntu 22.04+
- Docker
- Docker Compose

## Como executar
```bash
docker compose up -d
